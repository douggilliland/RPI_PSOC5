/* ========================================
 *
 * Copyright LAND BOARDS, LLC, 2019
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Land Boards.
 *
 * ========================================
*/
#ifndef TESTRASPIGVS_H
#define TESTRASPIGVS_H

#include <project.h>

void blinkLED(uint8);
void testRASPIGVS(void);

#endif

/* [] END OF FILE */
